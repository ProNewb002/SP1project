#ifndef _DATAFILE_
#define _DATAFILE_
// Positioning stats
short sLevel = 1;
// Character stats
short sHealth = 3;
int iCash = 50;
int iScore = 0;

#endif // _DATAFILE_H

